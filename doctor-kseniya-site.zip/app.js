const books = [
  ['Питание детей: рецепты на две недели','Дети','Питание детей','Материал на тему детского питания и рецептов.'],
  ['Крепкие нервы','Самочувствие','Крепкие нервы','Книга о стрессе и заботе о нервной системе.'],
  ['Витамин D: что важно знать','Питание','Витамин D','Материал о витамине D.'],
  ['Подготовка к беременности','Самочувствие','Подготовка к беременности','Книга на тему подготовки к беременности.'],
  ['Руководство по анемии','Питание','Об анемии','Материал на тему анемии.'],
  ['Педиатрическое меню','Дети','Педиатрическое меню','Меню для детского питания.'],
  ['Бессонница: разбираемся в причинах','Самочувствие','О сне','Материал о нарушениях сна.'],
  ['Хеликобактер, гастрит и язва: о здоровье желудка','ЖКТ','Здоровье желудка','Книга на тему хеликобактерной инфекции и заболеваний желудка.'],
  ['Вегетарианское меню на неделю','Питание','Меню на неделю','Вариант вегетарианского меню.'],
  ['Разнообразное меню на неделю','Питание','Меню на неделю','Материал с недельным меню.'],
  ['Доктор дома: лекарства и дети','Дети','Доктор дома','Материал для родителей о применении лекарств у детей.'],
  ['Витамин B9: о фолиевой кислоте','Питание','Витамин B9','Материал о фолиевой кислоте.'],
  ['Хроническая усталость: как разобраться','Самочувствие','Об усталости','Книга на тему хронической усталости.'],
  ['Боль в спине','Самочувствие','Боль в спине','Материал на тему боли в спине.'],
  ['Запор','ЖКТ','О пищеварении','Материал на тему нарушений стула.'],
  ['Костный бульон: как варить и зачем','Питание','Костный бульон','Материал о приготовлении костного бульона.'],
  ['Коллаген: вопросы и ответы','Питание','О коллагене','Материал на тему коллагена.'],
  ['Нервная система и стресс','Самочувствие','Нервы и стресс','Материал о нервной системе и стрессе.'],
  ['Медь и её роль в организме','Питание','О меди','Книга о меди.'],
  ['Цинк: что важно знать','Питание','О цинке','Материал о цинке.'],
  ['Остеопороз','Самочувствие','Здоровье костей','Материал на тему остеопороза.'],
  ['Общий анализ крови: разбираемся в показателях','Самочувствие','Анализ крови','Материал об общем анализе крови. Результаты обследований оценивает врач с учётом вашей ситуации.'],
  ['Нейромедиаторы','Самочувствие','Нейромедиаторы','Книга на тему нейромедиаторов.'],
  ['Снижение веса: питание и привычки','Питание','Снижение веса','Материал на тему снижения веса.']
];
const palettes=[['#e8ede4','#799077','#fff'],['#f0e8df','#ae8167','#fff'],['#f3eddb','#d9be76','#40553b'],['#eae8ef','#a99aac','#fff'],['#e7ece9','#657f7d','#fff'],['#eeeee0','#adb182','#354a37']];
const symbols=['✳','⌁','☼','❋','◉','✧'];
let category='Все',limit=8;
const grid=document.querySelector('#book-grid'),search=document.querySelector('#book-search'),more=document.querySelector('#show-more'),dialog=document.querySelector('#book-dialog');
function render(){
 const term=search.value.trim().toLocaleLowerCase('ru');
 const found=books.map((b,i)=>({b,i})).filter(({b})=>(category==='Все'||b[1]===category)&&b.join(' ').toLocaleLowerCase('ru').includes(term));
 grid.replaceChildren();
 found.slice(0,limit).forEach(({b,i})=>{
  const card=document.createElement('article');card.className='book-card';
  const p=palettes[i%palettes.length];card.style.cssText=`--stage:${p[0]};--cover:${p[1]};--coverink:${p[2]}`;
  card.innerHTML=`<div class="book-stage" aria-hidden="true"><div class="book-cover"><span class="book-author">Ксения Махова</span><span class="book-title"></span><span class="book-symbol">${symbols[i%symbols.length]}</span><span class="book-footer">Библиотека здоровья</span></div></div><p class="book-category"></p><h3></h3><p class="book-price">300 ₽ <span>электронная книга</span></p><button type="button">Узнать о книге ↗</button>`;
  card.querySelector('.book-title').textContent=b[2];card.querySelector('.book-category').textContent=b[1];card.querySelector('h3').textContent=b[0];
  card.querySelector('button').setAttribute('aria-label',`Узнать о книге «${b[0]}»`);
  card.querySelector('button').addEventListener('click',()=>{document.querySelector('#dialog-title').textContent=b[0];document.querySelector('#dialog-description').textContent=b[3];document.querySelector('#book-contact').href=`https://t.me/docKseniya?text=${encodeURIComponent('Здравствуйте, Ксения! Хочу купить за 300 рублей книгу «'+b[0]+'».')}`;dialog.showModal();});
  grid.append(card);
 });
 document.querySelector('#catalog-count').textContent=`В подборке: ${found.length} · Показано: ${Math.min(limit,found.length)}`;
 document.querySelector('#empty').hidden=found.length!==0;more.hidden=found.length<=limit;
}
document.querySelectorAll('.filter').forEach(btn=>btn.addEventListener('click',()=>{category=btn.dataset.category;limit=8;document.querySelectorAll('.filter').forEach(el=>{const active=el===btn;el.classList.toggle('active',active);el.setAttribute('aria-pressed',String(active));});render();}));
search.addEventListener('input',()=>{limit=8;render();});more.addEventListener('click',()=>{limit+=8;render();});
document.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
const menu=document.querySelector('.menu-toggle'),nav=document.querySelector('#navigation');
function closeMenu(){nav.classList.remove('open');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Открыть меню');}
menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Закрыть меню':'Открыть меню');});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});
document.querySelector('#year').textContent=new Date().getFullYear();render();

// Offer both messengers for every personal-contact action.
const contactDialog = document.querySelector('#contact-dialog');
document.querySelectorAll('a[href^="https://t.me/docKseniya"]').forEach(link => {
  if (link.id === 'book-contact' || link.id === 'contact-telegram') return;
  link.setAttribute('aria-haspopup', 'dialog');
  link.addEventListener('click', event => {
    event.preventDefault();
    document.querySelector('#contact-telegram').href = link.href;
    const message = new URL(link.href).searchParams.get('text');
    const context = document.querySelector('#contact-context');
    context.textContent = message ? 'Для вступления напишите: «Хочу в клуб здоровья ВК за 700 ₽ в месяц». В Telegram сообщение уже подготовлено.' : '';
    context.hidden = !message;
    contactDialog.showModal();
  });
});
document.querySelector('.contact-close').addEventListener('click', () => contactDialog.close());
contactDialog.addEventListener('click', event => {
  if (event.target !== contactDialog) return;
  const bounds = contactDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) contactDialog.close();
});
